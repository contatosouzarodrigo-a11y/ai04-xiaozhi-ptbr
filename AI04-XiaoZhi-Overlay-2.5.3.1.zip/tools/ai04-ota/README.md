# AI04 OTA relay

The reconstructed AI04 firmware keeps the official `davinci-ai04-c3` device
identity so XiaoZhi can supply activation, MQTT/WebSocket configuration and
time. It must not accept the official firmware offer directly: that offer may
replace the PT-BR build with another locale.

This Cloudflare Worker-compatible relay forwards the device request upstream
and preserves every upstream response field. For `davinci-ai04-c3` only, it
replaces `firmware` with the release described by a controlled manifest.

If that manifest is unavailable or invalid, the relay preserves activation and
backend settings but removes the firmware offer. This fail-closed behaviour is
intentional: an OTA-service outage must never install an English image.

## Deploy

1. Copy `wrangler.toml.example` to `wrangler.toml` in the Cloudflare account
   that will own the AI04 service.
2. Configure `XIAOZHI_UPSTREAM_URL` as
   `https://api.tenclass.net/xiaozhi/ota/` and configure
   `AI04_MANIFEST_URL` with your published manifest.
3. Publish a manifest matching `manifest.example.json`. Firmware versions must
   use numeric dot-separated components so the device can compare them.
4. Set `wifi.ota_url` to the deployed relay during USB migration. The board
   deliberately contains no default OTA address.

The Worker does not log request bodies or headers. Run local checks with:

```sh
npm test
```

XiaoZhi's cloud firmware builder currently accepts only boards already merged
into its public source tree. The reconstructed `davinci-ai04-c3` is not in that
list, so build the AI04 from this downstream source and use the relay rather
than the cloud builder for this board.
