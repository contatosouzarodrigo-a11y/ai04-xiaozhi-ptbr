const AI04_BOARD_TYPE = "davinci-ai04-c3";
const NUMERIC_VERSION = /^\d+(?:\.\d+)*$/;

function copiedRequestHeaders(headers) {
  const copied = new Headers();
  for (const [name, value] of headers) {
    const normalized = name.toLowerCase();
    if (["host", "content-length", "connection", "cf-connecting-ip"].includes(normalized)) {
      continue;
    }
    copied.set(name, value);
  }
  return copied;
}

function boardType(payload) {
  return payload?.board?.type
    ?? payload?.device?.board?.type
    ?? payload?.device?.type
    ?? payload?.board_type
    ?? payload?.type
    ?? null;
}

function validFirmware(firmware) {
  if (!firmware || typeof firmware !== "object") {
    return false;
  }
  if (typeof firmware.version !== "string" || !NUMERIC_VERSION.test(firmware.version)) {
    return false;
  }
  if (typeof firmware.url !== "string") {
    return false;
  }
  try {
    return new URL(firmware.url).protocol === "https:";
  } catch {
    return false;
  }
}

async function controlledFirmware(env, fetchImpl) {
  if (!env.AI04_MANIFEST_URL) {
    return null;
  }
  try {
    const response = await fetchImpl(env.AI04_MANIFEST_URL, {
      headers: { accept: "application/json" },
    });
    if (!response.ok) {
      return null;
    }
    const manifest = await response.json();
    const firmware = manifest?.firmware ?? manifest;
    return validFirmware(firmware) ? firmware : null;
  } catch {
    return null;
  }
}

function responseHeaders(upstream) {
  const headers = new Headers(upstream.headers);
  headers.delete("content-length");
  headers.set("content-type", "application/json; charset=utf-8");
  return headers;
}

/**
 * Relay XiaoZhi's configuration response while taking ownership of only the
 * firmware offer for the reconstructed AI04.  A controlled-manifest outage is
 * intentionally fail-closed: activation/MQTT fields still pass through, but
 * the official firmware offer is removed rather than risking an English build.
 */
export async function handleRequest(request, env, fetchImpl = fetch) {
  if (!env.XIAOZHI_UPSTREAM_URL) {
    return new Response("XIAOZHI_UPSTREAM_URL is not configured", { status: 500 });
  }

  const body = await request.text();
  let payload = null;
  try {
    payload = body ? JSON.parse(body) : null;
  } catch {
    // The upstream is still allowed to diagnose malformed requests.
  }

  const upstream = await fetchImpl(env.XIAOZHI_UPSTREAM_URL, {
    method: request.method,
    headers: copiedRequestHeaders(request.headers),
    body: body || undefined,
  });
  const upstreamBody = await upstream.text();

  if (boardType(payload) !== AI04_BOARD_TYPE) {
    return new Response(upstreamBody, {
      status: upstream.status,
      statusText: upstream.statusText,
      headers: upstream.headers,
    });
  }

  let responsePayload;
  try {
    responsePayload = JSON.parse(upstreamBody);
  } catch {
    return new Response(upstreamBody, {
      status: upstream.status,
      statusText: upstream.statusText,
      headers: upstream.headers,
    });
  }

  const firmware = await controlledFirmware(env, fetchImpl);
  if (firmware) {
    responsePayload.firmware = firmware;
  } else {
    delete responsePayload.firmware;
  }
  return new Response(JSON.stringify(responsePayload), {
    status: upstream.status,
    statusText: upstream.statusText,
    headers: responseHeaders(upstream),
  });
}

export default {
  fetch(request, env) {
    return handleRequest(request, env);
  },
};
