import assert from "node:assert/strict";
import test from "node:test";

import { handleRequest } from "./worker.js";

const env = {
  XIAOZHI_UPSTREAM_URL: "https://official.example/ota/",
  AI04_MANIFEST_URL: "https://releases.example/ai04.json",
};

function request(boardType = "davinci-ai04-c3") {
  return new Request("https://worker.example/ota/", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer test" },
    body: JSON.stringify({ device: { type: boardType } }),
  });
}

function jsonResponse(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "content-type": "application/json", "x-upstream": "kept" },
  });
}

test("replaces only the AI04 firmware offer", async () => {
  const fetchImpl = async (url, options) => {
    if (url === env.AI04_MANIFEST_URL) {
      return jsonResponse({ firmware: { version: "2.5.3.1", url: "https://releases.example/ai04.bin" } });
    }
    assert.equal(url, env.XIAOZHI_UPSTREAM_URL);
    assert.equal(options.headers.get("authorization"), "Bearer test");
    return jsonResponse({ activation: { code: "kept" }, firmware: { version: "99.0.0", url: "https://official.example/en.bin" } });
  };
  const response = await handleRequest(request(), env, fetchImpl);
  const value = await response.json();
  assert.deepEqual(value, {
    activation: { code: "kept" },
    firmware: { version: "2.5.3.1", url: "https://releases.example/ai04.bin" },
  });
  assert.equal(response.headers.get("x-upstream"), "kept");
});

test("leaves other board types untouched", async () => {
  let calls = 0;
  const fetchImpl = async () => {
    calls += 1;
    return jsonResponse({ firmware: { version: "7.0.0", url: "https://official.example/other.bin" } });
  };
  const response = await handleRequest(request("other-board"), env, fetchImpl);
  assert.deepEqual(await response.json(), { firmware: { version: "7.0.0", url: "https://official.example/other.bin" } });
  assert.equal(calls, 1);
});

test("suppresses the official offer when the manifest is unavailable", async () => {
  const fetchImpl = async (url) => {
    if (url === env.AI04_MANIFEST_URL) {
      return new Response("down", { status: 503 });
    }
    return jsonResponse({ activation: { code: "kept" }, firmware: { version: "7.0.0", url: "https://official.example/en.bin" } });
  };
  const response = await handleRequest(request(), env, fetchImpl);
  assert.deepEqual(await response.json(), { activation: { code: "kept" } });
});

test("forwards activation and backend settings while replacing firmware", async () => {
  const fetchImpl = async (url) => {
    if (url === env.AI04_MANIFEST_URL) {
      return jsonResponse({ version: "2.5.3.2", url: "https://releases.example/next.bin" });
    }
    return jsonResponse({
      activation: { code: "123456" },
      mqtt: { endpoint: "wss://mqtt.example" },
      server_time: 42,
      firmware: { version: "7.0.0", url: "https://official.example/en.bin" },
    });
  };
  const response = await handleRequest(request(), env, fetchImpl);
  const value = await response.json();
  assert.equal(value.activation.code, "123456");
  assert.equal(value.mqtt.endpoint, "wss://mqtt.example");
  assert.equal(value.server_time, 42);
  assert.deepEqual(value.firmware, { version: "2.5.3.2", url: "https://releases.example/next.bin" });
});
