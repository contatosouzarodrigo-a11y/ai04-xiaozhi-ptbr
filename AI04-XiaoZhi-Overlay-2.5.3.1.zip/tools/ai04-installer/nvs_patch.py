#!/usr/bin/env python3
"""Safely prepare an ESP-IDF NVS partition for an AI04 USB migration.

The stock AI04 updater preserves the NVS partition because it contains device
activation and other board-specific state. This tool follows the same
principle: it only retires and replaces four entries in the ``wifi`` namespace
(``ssid``, ``password``, ``channel`` and ``ota_url``). It deliberately rejects
encrypted, malformed, or unfamiliar page layouts instead of guessing.

The implementation is dependency-free so it can be bundled into the Windows
installer. It supports the ESP-IDF NVS v1/v2 page formats for primitive and
string entries; it does not attempt to rewrite blobs or encrypted partitions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


PAGE_SIZE = 4096
PAGE_HEADER_SIZE = 32
BITMAP_OFFSET = 32
ENTRY_OFFSET = 64
ENTRY_SIZE = 32
ENTRIES_PER_PAGE = 126

PAGE_ACTIVE = 0xFFFFFFFE
PAGE_FULL = 0xFFFFFFFC
PAGE_EMPTY = 0xFFFFFFFF
VERSION_V1 = 0xFF
VERSION_V2 = 0xFE

TYPE_U8 = 0x01
TYPE_STRING = 0x21

STATE_EMPTY = 0b11
STATE_WRITTEN = 0b10
STATE_ERASED = 0b00

WIFI_KEYS = ("ssid", "password", "channel", "ota_url")


class NvsFormatError(ValueError):
    """The image cannot be changed without risking unrelated NVS data."""


@dataclass(frozen=True)
class PageInfo:
    index: int
    state: int
    sequence: int | None
    version: int | None


@dataclass(frozen=True)
class Record:
    page: int
    sequence: int
    slot: int
    slots: tuple[int, ...]
    namespace: int
    item_type: int
    key: str
    entry: bytes

    @property
    def order(self) -> tuple[int, int]:
        return (self.sequence, self.slot)


def _crc32(data: bytes) -> int:
    return zlib.crc32(data, 0xFFFFFFFF) & 0xFFFFFFFF


def _header_crc_valid(entry: bytes) -> bool:
    if len(entry) != ENTRY_SIZE:
        return False
    expected = struct.unpack_from("<I", entry, 4)[0]
    return expected == _crc32(entry[0:4] + entry[8:32])


def _page_header_valid(page: bytes) -> bool:
    if len(page) != PAGE_SIZE:
        return False
    expected = struct.unpack_from("<I", page, 28)[0]
    return expected == _crc32(page[4:28])


def _state_at(page: bytes | bytearray, slot: int) -> int:
    byte_offset = BITMAP_OFFSET + (slot * 2 // 8)
    shift = (slot * 2) & 7
    return (page[byte_offset] >> shift) & 0b11


def _set_state(page: bytearray, slot: int, new_state: int) -> None:
    if not 0 <= new_state <= 0b11:
        raise ValueError("invalid NVS entry state")
    byte_offset = BITMAP_OFFSET + (slot * 2 // 8)
    shift = (slot * 2) & 7
    old_byte = page[byte_offset]
    old_state = (old_byte >> shift) & 0b11
    # NVS state transitions may only clear flash bits (1 -> 0).
    if (old_state | new_state) != old_state:
        raise NvsFormatError("NVS update would require setting a flash bit")
    mask = 0b11 << shift
    page[byte_offset] = (old_byte & ~mask) | (new_state << shift)


def _key_from_entry(entry: bytes) -> str:
    raw = entry[8:24].split(b"\0", 1)[0]
    try:
        return raw.decode("ascii")
    except UnicodeDecodeError as exc:
        raise NvsFormatError("NVS contains a non-ASCII key") from exc


def _entry_bytes(page: bytes | bytearray, slot: int) -> bytes:
    start = ENTRY_OFFSET + slot * ENTRY_SIZE
    return bytes(page[start : start + ENTRY_SIZE])


def _slot_range(slot: int, span: int) -> tuple[int, ...]:
    return tuple(range(slot, slot + span))


def _parse_page(image: bytes | bytearray, page_index: int) -> tuple[PageInfo, list[Record]]:
    offset = page_index * PAGE_SIZE
    page = image[offset : offset + PAGE_SIZE]
    state = struct.unpack_from("<I", page, 0)[0]
    if state == PAGE_EMPTY:
        if any(byte != 0xFF for byte in page):
            raise NvsFormatError(f"page {page_index} has data but no valid header")
        return PageInfo(page_index, state, None, None), []
    if state not in (PAGE_ACTIVE, PAGE_FULL):
        raise NvsFormatError(f"page {page_index} has unsupported state 0x{state:08x}")
    if not _page_header_valid(page):
        raise NvsFormatError(f"page {page_index} has an invalid header CRC (encrypted or corrupt NVS)")
    version = page[8]
    if version not in (VERSION_V1, VERSION_V2):
        raise NvsFormatError(f"page {page_index} has unsupported NVS version 0x{version:02x}")
    sequence = struct.unpack_from("<I", page, 4)[0]
    info = PageInfo(page_index, state, sequence, version)

    records: list[Record] = []
    slot = 0
    while slot < ENTRIES_PER_PAGE:
        entry_state = _state_at(page, slot)
        if entry_state in (STATE_EMPTY, STATE_ERASED):
            slot += 1
            continue
        if entry_state != STATE_WRITTEN:
            raise NvsFormatError(f"page {page_index}, slot {slot} has invalid bitmap state")

        entry = _entry_bytes(page, slot)
        if not _header_crc_valid(entry):
            # Raw string/blob payloads are skipped together with their header.
            # Seeing one on its own means the partition is not safe to edit.
            raise NvsFormatError(f"page {page_index}, slot {slot} has an invalid entry CRC")
        span = entry[2]
        if span < 1 or slot + span > ENTRIES_PER_PAGE:
            raise NvsFormatError(f"page {page_index}, slot {slot} has an invalid entry span")
        slots = _slot_range(slot, span)
        if any(_state_at(page, item_slot) != STATE_WRITTEN for item_slot in slots):
            raise NvsFormatError(f"page {page_index}, slot {slot} has an incomplete entry")
        records.append(
            Record(
                page=page_index,
                sequence=sequence,
                slot=slot,
                slots=slots,
                namespace=entry[0],
                item_type=entry[1],
                key=_key_from_entry(entry),
                entry=entry,
            )
        )
        slot += span
    return info, records


def parse_nvs(image: bytes | bytearray) -> tuple[list[PageInfo], list[Record]]:
    """Parse a plaintext NVS partition and validate its editable structure."""
    if len(image) != 0x4000:
        raise NvsFormatError("expected a 0x4000-byte (16 KiB) NVS partition")
    pages: list[PageInfo] = []
    records: list[Record] = []
    for page_index in range(len(image) // PAGE_SIZE):
        info, page_records = _parse_page(image, page_index)
        pages.append(info)
        records.extend(page_records)
    active_pages = [page for page in pages if page.state == PAGE_ACTIVE]
    if len(active_pages) != 1:
        raise NvsFormatError(f"expected exactly one active NVS page, found {len(active_pages)}")
    return pages, records


def _namespace_map(records: Iterable[Record]) -> dict[str, int]:
    by_name: dict[str, int] = {}
    for record in sorted(records, key=lambda item: item.order):
        if record.namespace != 0 or record.item_type != TYPE_U8 or record.entry[2] != 1:
            continue
        index = record.entry[24]
        if not record.key:
            raise NvsFormatError("NVS has a namespace with an empty name")
        previous = by_name.get(record.key)
        if previous is not None and previous != index:
            raise NvsFormatError(f"NVS has conflicting namespace entries for {record.key!r}")
        by_name[record.key] = index
    return by_name


def _make_header(namespace: int, item_type: int, span: int, key: str) -> bytearray:
    if not 0 <= namespace <= 0xFF:
        raise ValueError("invalid namespace index")
    if not key or len(key.encode("ascii")) > 15:
        raise ValueError("NVS keys must be 1-15 ASCII characters")
    result = bytearray(b"\xff" * ENTRY_SIZE)
    result[0] = namespace
    result[1] = item_type
    result[2] = span
    result[3] = 0xFF
    result[8:24] = b"\0" * 16
    result[8 : 8 + len(key)] = key.encode("ascii")
    return result


def _finalize_header(header: bytearray) -> bytes:
    struct.pack_into("<I", header, 4, _crc32(header[0:4] + header[8:32]))
    return bytes(header)


def _make_u8_entry(namespace: int, key: str, value: int) -> list[bytes]:
    if not 0 <= value <= 0xFF:
        raise ValueError("u8 value outside range")
    header = _make_header(namespace, TYPE_U8, 1, key)
    header[24] = value
    return [_finalize_header(header)]


def _make_string_entries(namespace: int, key: str, value: str) -> list[bytes]:
    payload = value.encode("utf-8") + b"\0"
    chunks = (len(payload) + ENTRY_SIZE - 1) // ENTRY_SIZE
    if chunks < 1 or chunks + 1 > ENTRIES_PER_PAGE:
        raise ValueError(f"NVS string for {key!r} is too long")
    header = _make_header(namespace, TYPE_STRING, chunks + 1, key)
    struct.pack_into("<H", header, 24, len(payload))
    struct.pack_into("<I", header, 28, _crc32(payload))
    output = [_finalize_header(header)]
    for start in range(0, len(payload), ENTRY_SIZE):
        output.append(payload[start : start + ENTRY_SIZE].ljust(ENTRY_SIZE, b"\xff"))
    return output


def _entry_offset(slot: int) -> int:
    return ENTRY_OFFSET + slot * ENTRY_SIZE


def _append_entries(page: bytearray, start_slot: int, entries: list[bytes]) -> None:
    for relative_slot, entry in enumerate(entries):
        slot = start_slot + relative_slot
        if _state_at(page, slot) != STATE_EMPTY:
            raise NvsFormatError("selected NVS slots are no longer empty")
        offset = _entry_offset(slot)
        if any(byte != 0xFF for byte in page[offset : offset + ENTRY_SIZE]):
            raise NvsFormatError("empty NVS bitmap slot contains data; refusing to overwrite it")
        page[offset : offset + ENTRY_SIZE] = entry
        _set_state(page, slot, STATE_WRITTEN)


def _first_append_slot(page: bytes | bytearray) -> int:
    for slot in range(ENTRIES_PER_PAGE):
        if _state_at(page, slot) == STATE_EMPTY:
            if any(_state_at(page, later) != STATE_EMPTY for later in range(slot, ENTRIES_PER_PAGE)):
                raise NvsFormatError("NVS page has non-contiguous empty slots")
            return slot
    return ENTRIES_PER_PAGE


def _initialize_page(image: bytearray, page_index: int, sequence: int, version: int) -> None:
    start = page_index * PAGE_SIZE
    page = image[start : start + PAGE_SIZE]
    if any(byte != 0xFF for byte in page):
        raise NvsFormatError("requested replacement NVS page is not erased")
    header = bytearray(b"\xff" * PAGE_HEADER_SIZE)
    struct.pack_into("<I", header, 0, PAGE_ACTIVE)
    struct.pack_into("<I", header, 4, sequence)
    header[8] = version
    struct.pack_into("<I", header, 28, _crc32(header[4:28]))
    image[start : start + PAGE_HEADER_SIZE] = header


def _select_append_page(image: bytearray, pages: list[PageInfo], required_slots: int) -> tuple[int, int]:
    active = next(page for page in pages if page.state == PAGE_ACTIVE)
    active_start = active.index * PAGE_SIZE
    active_data = image[active_start : active_start + PAGE_SIZE]
    append_slot = _first_append_slot(active_data)
    if ENTRIES_PER_PAGE - append_slot >= required_slots:
        return active.index, append_slot

    # NVS leaves the final physical page reserved for garbage collection. If
    # the active page is full, create a new active page only from another
    # completely blank page and leave that reserved page untouched.
    replacement = next((page for page in pages[:-1] if page.state == PAGE_EMPTY), None)
    if replacement is None:
        raise NvsFormatError("not enough NVS space to update Wi-Fi safely")
    if required_slots > ENTRIES_PER_PAGE:
        raise NvsFormatError("new Wi-Fi settings exceed one NVS page")
    assert active.sequence is not None and active.version is not None
    max_sequence = max(page.sequence or 0 for page in pages)
    _initialize_page(image, replacement.index, max_sequence + 1, active.version)
    # ACTIVE (..1110) -> FULL (..1100) only clears a flash bit.
    struct.pack_into("<I", image, active_start, PAGE_FULL)
    return replacement.index, 0


def _validate_wifi_value(name: str, value: str, maximum_bytes: int, allow_empty: bool = False) -> None:
    if not isinstance(value, str) or (not value and not allow_empty):
        raise ValueError(f"{name} must not be empty")
    if "\0" in value or "\n" in value or "\r" in value:
        raise ValueError(f"{name} cannot contain a control character")
    if len(value.encode("utf-8")) > maximum_bytes:
        raise ValueError(f"{name} exceeds {maximum_bytes} UTF-8 bytes")


def patch_nvs(image: bytes, ssid: str, password: str, ota_url: str, channel: int = 0) -> tuple[bytes, dict[str, object]]:
    """Return a copy of *image* with AI04 Wi-Fi and controlled OTA settings.

    Only the four AI04 Wi-Fi records are retired. Every other byte in the
    partition is preserved, including activation state and unrelated settings.
    """
    _validate_wifi_value("SSID", ssid, 32)
    _validate_wifi_value("password", password, 63, allow_empty=True)
    _validate_wifi_value("OTA URL", ota_url, 512)
    if not ota_url.startswith("https://"):
        raise ValueError("OTA URL must use HTTPS")
    if not 0 <= channel <= 14:
        raise ValueError("Wi-Fi channel must be between 0 and 14")

    output = bytearray(image)
    pages, records = parse_nvs(output)
    namespaces = _namespace_map(records)
    wifi_namespace = namespaces.get("wifi")
    created_namespace = wifi_namespace is None
    if wifi_namespace is None:
        used_indexes = {record.namespace for record in records}
        used_indexes.update(namespaces.values())
        wifi_namespace = max(used_indexes, default=0) + 1
        if wifi_namespace > 0xFE:
            raise NvsFormatError("no namespace index is available for Wi-Fi")

    replacements: list[bytes] = []
    if created_namespace:
        replacements.extend(_make_u8_entry(0, "wifi", wifi_namespace))
    replacements.extend(_make_string_entries(wifi_namespace, "ssid", ssid))
    replacements.extend(_make_string_entries(wifi_namespace, "password", password))
    replacements.extend(_make_u8_entry(wifi_namespace, "channel", channel))
    replacements.extend(_make_string_entries(wifi_namespace, "ota_url", ota_url))

    append_page_index, append_slot = _select_append_page(output, pages, len(replacements))

    retired = 0
    for record in records:
        if record.namespace != wifi_namespace or record.key not in WIFI_KEYS:
            continue
        page_start = record.page * PAGE_SIZE
        page_data = output[page_start : page_start + PAGE_SIZE]
        for slot in record.slots:
            if _state_at(page_data, slot) == STATE_WRITTEN:
                _set_state(page_data, slot, STATE_ERASED)
                retired += 1
        output[page_start : page_start + PAGE_SIZE] = page_data

    append_start = append_page_index * PAGE_SIZE
    append_data = output[append_start : append_start + PAGE_SIZE]
    _append_entries(append_data, append_slot, replacements)
    output[append_start : append_start + PAGE_SIZE] = append_data

    # Parse once more before returning an image intended to be flashed.
    _, verified_records = parse_nvs(output)
    verified_namespaces = _namespace_map(verified_records)
    if verified_namespaces.get("wifi") != wifi_namespace:
        raise NvsFormatError("post-write NVS verification could not find the Wi-Fi namespace")
    expected = {"ssid", "password", "channel", "ota_url"}
    found = {
        record.key
        for record in verified_records
        if record.namespace == wifi_namespace and record.key in expected
    }
    if found != expected:
        raise NvsFormatError("post-write NVS verification did not find every Wi-Fi key")

    summary: dict[str, object] = {
        "wifi_namespace": wifi_namespace,
        "created_wifi_namespace": created_namespace,
        "retired_entries": retired,
        "written_entries": len(replacements),
        "sha256": hashlib.sha256(output).hexdigest(),
    }
    return bytes(output), summary


def inspect_nvs(image: bytes) -> dict[str, object]:
    """Return a non-secret structural summary suitable for installer logging."""
    pages, records = parse_nvs(image)
    namespaces = _namespace_map(records)
    keys_by_namespace: dict[str, list[str]] = {name: [] for name in namespaces}
    namespace_names = {index: name for name, index in namespaces.items()}
    for record in records:
        namespace_name = namespace_names.get(record.namespace)
        if namespace_name is not None and record.namespace != 0:
            keys_by_namespace[namespace_name].append(record.key)
    return {
        "pages": [
            {"index": page.index, "state": f"0x{page.state:08x}", "sequence": page.sequence}
            for page in pages
        ],
        "namespaces": {name: sorted(set(keys)) for name, keys in sorted(keys_by_namespace.items())},
        "sha256": hashlib.sha256(image).hexdigest(),
    }


def _read_password(args: argparse.Namespace) -> str:
    if args.password is not None:
        return args.password
    if args.password_stdin:
        value = sys.stdin.readline()
        if value.endswith("\n"):
            value = value[:-1]
        if value.endswith("\r"):
            value = value[:-1]
        return value
    raise ValueError("one of --password or --password-stdin is required")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="original 0x4000-byte NVS image")
    parser.add_argument("--output", type=Path, help="patched NVS output image")
    parser.add_argument("--inspect", action="store_true", help="validate and show a non-secret summary only")
    parser.add_argument("--ssid", help="Wi-Fi SSID")
    password = parser.add_mutually_exclusive_group()
    password.add_argument("--password", help="Wi-Fi password (avoid this on shared systems)")
    password.add_argument("--password-stdin", action="store_true", help="read the password from standard input")
    parser.add_argument("--ota-url", help="controlled HTTPS AI04 OTA relay URL")
    parser.add_argument("--channel", type=int, default=0, help="Wi-Fi channel (0 enables scan; default: 0)")
    args = parser.parse_args(argv)

    try:
        original = args.input.read_bytes()
        if args.inspect:
            if args.output or args.ssid or args.password is not None or args.password_stdin or args.ota_url:
                raise ValueError("--inspect cannot be combined with patch options")
            print(json.dumps(inspect_nvs(original), indent=2, sort_keys=True))
            return 0
        if not args.output or args.ssid is None or args.ota_url is None:
            raise ValueError("--output, --ssid and --ota-url are required when patching")
        password_value = _read_password(args)
        patched, summary = patch_nvs(original, args.ssid, password_value, args.ota_url, args.channel)
        args.output.write_bytes(patched)
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 0
    except (OSError, ValueError, NvsFormatError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
