# Build the two helper executables on Windows. Run this script on Windows so
# PyInstaller produces Windows executables; do not copy Linux-built binaries.
[CmdletBinding()]
param(
    [string]$Python = "py",
    [string]$OutputDirectory = (Join-Path $PSScriptRoot "windows-tools")
)

$ErrorActionPreference = "Stop"
$pythonArgs = @()
if ($Python -eq "py") {
    $pythonArgs = @("-3")
}

& $Python @pythonArgs -m pip install --upgrade "esptool==5.6.0" "pyinstaller==6.11.1"
if ($LASTEXITCODE -ne 0) { throw "Could not install the Windows build dependencies." }

$work = Join-Path $env:TEMP "ai04-installer-pyinstaller"
New-Item -ItemType Directory -Force -Path $work | Out-Null
Push-Location $work
try {
    & $Python @pythonArgs -m PyInstaller --noconfirm --clean --onefile --name nvs_patch $PSScriptRoot\nvs_patch.py
    if ($LASTEXITCODE -ne 0) { throw "Could not package nvs_patch.exe." }
    & $Python @pythonArgs -m PyInstaller --noconfirm --clean --onefile --collect-all esptool --name esptool $PSScriptRoot\esptool_runner.py
    if ($LASTEXITCODE -ne 0) { throw "Could not package esptool.exe." }
    New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
    Copy-Item (Join-Path $work "dist\nvs_patch.exe") (Join-Path $OutputDirectory "nvs_patch.exe") -Force
    Copy-Item (Join-Path $work "dist\esptool.exe") (Join-Path $OutputDirectory "esptool.exe") -Force
} finally {
    Pop-Location
}

Write-Host "Windows helpers written to $OutputDirectory"
