#!/usr/bin/env python3
"""Unit checks for the conservative AI04 NVS patcher."""

from __future__ import annotations

import struct
import unittest

import nvs_patch


def make_fixture() -> bytes:
    image = bytearray(b"\xff" * 0x4000)
    nvs_patch._initialize_page(image, 0, 7, nvs_patch.VERSION_V1)
    page = image[: nvs_patch.PAGE_SIZE]
    entries = []
    entries += nvs_patch._make_u8_entry(0, "wifi", 1)
    entries += nvs_patch._make_u8_entry(0, "settings", 2)
    entries += nvs_patch._make_string_entries(1, "ssid", "Old network")
    entries += nvs_patch._make_string_entries(1, "password", "old-secret")
    entries += nvs_patch._make_u8_entry(1, "channel", 6)
    entries += nvs_patch._make_string_entries(1, "ota_url", "https://old.example/ota/")
    entries += nvs_patch._make_string_entries(2, "device_id", "keep-me")
    nvs_patch._append_entries(page, 0, entries)
    image[: nvs_patch.PAGE_SIZE] = page
    return bytes(image)


def string_value(image: bytes, record: nvs_patch.Record) -> str:
    assert record.item_type == nvs_patch.TYPE_STRING
    length = struct.unpack_from("<H", record.entry, 24)[0]
    page = image[record.page * nvs_patch.PAGE_SIZE : (record.page + 1) * nvs_patch.PAGE_SIZE]
    payload = bytearray()
    for slot in record.slots[1:]:
        payload.extend(nvs_patch._entry_bytes(page, slot))
    assert nvs_patch._crc32(bytes(payload[:length])) == struct.unpack_from("<I", record.entry, 28)[0]
    return bytes(payload[:length]).rstrip(b"\0").decode("utf-8")


class NvsPatchTests(unittest.TestCase):
    def test_replaces_wifi_without_touching_another_namespace(self) -> None:
        original = make_fixture()
        patched, summary = nvs_patch.patch_nvs(
            original,
            ssid="Casa 2G",
            password="senha-segura",
            ota_url="https://ota.example.net/ota/",
        )
        self.assertGreater(summary["retired_entries"], 0)
        self.assertEqual(len(patched), 0x4000)

        _, records = nvs_patch.parse_nvs(patched)
        namespaces = nvs_patch._namespace_map(records)
        self.assertEqual(namespaces, {"wifi": 1, "settings": 2})
        latest: dict[str, nvs_patch.Record] = {}
        for record in records:
            if record.namespace == 1:
                latest[record.key] = record
        self.assertEqual(string_value(patched, latest["ssid"]), "Casa 2G")
        self.assertEqual(string_value(patched, latest["password"]), "senha-segura")
        self.assertEqual(latest["channel"].entry[24], 0)
        self.assertEqual(string_value(patched, latest["ota_url"]), "https://ota.example.net/ota/")
        kept = next(record for record in records if record.namespace == 2 and record.key == "device_id")
        self.assertEqual(string_value(patched, kept), "keep-me")

    def test_creates_wifi_namespace_when_missing(self) -> None:
        image = bytearray(b"\xff" * 0x4000)
        nvs_patch._initialize_page(image, 0, 1, nvs_patch.VERSION_V1)
        patched, summary = nvs_patch.patch_nvs(
            bytes(image),
            ssid="Lab",
            password="12345678",
            ota_url="https://ota.example.net/ota/",
        )
        self.assertTrue(summary["created_wifi_namespace"])
        _, records = nvs_patch.parse_nvs(patched)
        self.assertEqual(nvs_patch._namespace_map(records), {"wifi": 1})

    def test_uses_new_page_when_active_page_lacks_space(self) -> None:
        image = bytearray(make_fixture())
        page = image[: nvs_patch.PAGE_SIZE]
        start = nvs_patch._first_append_slot(page)
        filler = nvs_patch._make_u8_entry(2, "fill", 1)
        while nvs_patch.ENTRIES_PER_PAGE - start > 5:
            nvs_patch._append_entries(page, start, filler)
            start += 1
        image[: nvs_patch.PAGE_SIZE] = page
        patched, _ = nvs_patch.patch_nvs(
            bytes(image),
            ssid="Office",
            password="12345678",
            ota_url="https://ota.example.net/ota/",
        )
        pages, _ = nvs_patch.parse_nvs(patched)
        self.assertEqual(pages[0].state, nvs_patch.PAGE_FULL)
        self.assertEqual(pages[1].state, nvs_patch.PAGE_ACTIVE)

    def test_rejects_bad_header_crc(self) -> None:
        image = bytearray(make_fixture())
        image[28] ^= 0x01
        with self.assertRaises(nvs_patch.NvsFormatError):
            nvs_patch.patch_nvs(
                bytes(image),
                ssid="Office",
                password="12345678",
                ota_url="https://ota.example.net/ota/",
            )

    def test_rejects_non_https_ota(self) -> None:
        with self.assertRaises(ValueError):
            nvs_patch.patch_nvs(
                make_fixture(),
                ssid="Office",
                password="12345678",
                ota_url="http://ota.example.net/ota/",
            )


if __name__ == "__main__":
    unittest.main()
