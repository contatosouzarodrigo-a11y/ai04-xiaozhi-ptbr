"""Small PyInstaller entry point for the pinned esptool release."""

from esptool import main


if __name__ == "__main__":
    main()
