# AI04 USB migration installer for Windows.
# The script makes a complete 8 MiB backup before it changes the flash.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Port,

    [Parameter(Mandatory = $true)]
    [string]$Ssid,

    [System.Security.SecureString]$WifiPassword,

    [switch]$OpenNetwork,

    [Parameter(Mandatory = $true)]
    [ValidatePattern("^https://")]
    [string]$OtaUrl,

    [ValidateRange(0, 14)]
    [int]$Channel = 0,

    [ValidateRange(115200, 921600)]
    [int]$Baud = 460800,

    [string]$BackupDirectory = (Join-Path $PSScriptRoot "backups"),

    [switch]$Confirm
)

$ErrorActionPreference = "Stop"
$expectedFlashSize = 8 * 1024 * 1024
$payloadDirectory = Join-Path $PSScriptRoot "payload"
$releasePath = Join-Path $PSScriptRoot "release.json"

function Require-File([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Arquivo obrigatório não encontrado: $Path"
    }
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Invoke-Esptool([string[]]$Arguments) {
    if ($script:EsptoolExe) {
        & $script:EsptoolExe @Arguments
    } else {
        & $script:PythonExe $script:PythonPrefix "-m" "esptool" @Arguments
    }
    if ($LASTEXITCODE -ne 0) {
        throw "esptool falhou (código $LASTEXITCODE). Nenhuma etapa seguinte foi executada."
    }
}

function Invoke-NvsPatcher([string]$Input, [string]$Output, [string]$Password) {
    $arguments = @(
        "--input", $Input,
        "--output", $Output,
        "--ssid", $Ssid,
        "--password-stdin",
        "--ota-url", $OtaUrl,
        "--channel", $Channel
    )
    try {
        # Password uses stdin rather than a command-line argument.
        $Password | & $script:NvsPatcherExe $script:NvsPatcherPrefix @arguments
    } finally {
        $Password = $null
    }
    if ($LASTEXITCODE -ne 0) {
        throw "Não foi possível preparar a NVS. O firmware não foi gravado."
    }
}

function Copy-Range([string]$Input, [string]$Output, [Int64]$Offset, [Int64]$Length) {
    $source = [System.IO.File]::OpenRead($Input)
    $destination = [System.IO.File]::Create($Output)
    try {
        [void]$source.Seek($Offset, [System.IO.SeekOrigin]::Begin)
        $buffer = New-Object byte[] 65536
        $remaining = $Length
        while ($remaining -gt 0) {
            $read = $source.Read($buffer, 0, [Math]::Min($buffer.Length, $remaining))
            if ($read -le 0) { throw "O backup terminou antes da região NVS." }
            $destination.Write($buffer, 0, $read)
            $remaining -= $read
        }
    } finally {
        $destination.Dispose()
        $source.Dispose()
    }
}

Require-File $releasePath
$release = Get-Content -LiteralPath $releasePath -Raw | ConvertFrom-Json
if ($release.board -ne "davinci-ai04-c3" -or $release.flash_size -ne $expectedFlashSize) {
    throw "release.json não é um pacote AI04 C3 de 8 MiB válido."
}
foreach ($property in $release.payload.PSObject.Properties) {
    $path = Join-Path $payloadDirectory $property.Name
    Require-File $path
    if ((Get-Sha256 $path) -ne $property.Value.sha256.ToLowerInvariant()) {
        throw "Checksum inválido no payload: $($property.Name)"
    }
}

$script:EsptoolExe = Join-Path $PSScriptRoot "tools\esptool.exe"
if (-not (Test-Path -LiteralPath $script:EsptoolExe -PathType Leaf)) {
    $script:EsptoolExe = $null
    $py = Get-Command py -ErrorAction SilentlyContinue
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($py) {
        $script:PythonExe = $py.Source
        $script:PythonPrefix = @("-3")
    } elseif ($python) {
        $script:PythonExe = $python.Source
        $script:PythonPrefix = @()
    } else {
        throw "Instale Python 3 com esptool 5.6.0 ou inclua tools\esptool.exe no pacote."
    }
}

$script:NvsPatcherExe = Join-Path $PSScriptRoot "tools\nvs_patch.exe"
if (Test-Path -LiteralPath $script:NvsPatcherExe -PathType Leaf) {
    $script:NvsPatcherPrefix = @()
} else {
    if (-not $script:PythonExe) {
        throw "tools\nvs_patch.exe não foi encontrado e não há Python disponível."
    }
    $script:NvsPatcherExe = $script:PythonExe
    $script:NvsPatcherPrefix = @($script:PythonPrefix + (Join-Path $PSScriptRoot "nvs_patch.py"))
}

if (-not $OpenNetwork -and -not $WifiPassword) {
    $WifiPassword = Read-Host "Senha do Wi-Fi" -AsSecureString
}
if ($OpenNetwork) {
    $plainPassword = ""
} else {
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($WifiPassword)
    try {
        $plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

if (-not $Confirm) {
    Write-Host "Este processo cria um backup completo de 8 MiB antes de gravar o firmware PT-BR."
    $answer = Read-Host "Digite AI04 para continuar"
    if ($answer -cne "AI04") {
        Write-Host "Cancelado. Nenhum dado foi gravado."
        exit 0
    }
}

New-Item -ItemType Directory -Force -Path $BackupDirectory | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $BackupDirectory "ai04-backup-$stamp.bin"
$nvsOriginal = Join-Path $BackupDirectory "ai04-nvs-original-$stamp.bin"
$nvsPrepared = Join-Path $BackupDirectory "ai04-nvs-prepared-$stamp.bin"

Invoke-Esptool @("--chip", "esp32c3", "--port", $Port, "--baud", $Baud, "chip-id")
Invoke-Esptool @("--chip", "esp32c3", "--port", $Port, "--baud", $Baud, "read-flash", "0x0", "0x800000", $backup)
if ((Get-Item -LiteralPath $backup).Length -ne $expectedFlashSize) {
    throw "O backup não tem 8 MiB. O firmware não foi gravado."
}
Copy-Range $backup $nvsOriginal 0x9000 0x4000
Invoke-NvsPatcher $nvsOriginal $nvsPrepared $plainPassword
$plainPassword = $null

$flash = @(
    "--chip", "esp32c3", "--port", $Port, "--baud", $Baud,
    "write-flash", "--flash-mode", "dio", "--flash-freq", "80m", "--flash-size", "8MB",
    "0x0", (Join-Path $payloadDirectory "bootloader.bin"),
    "0x8000", (Join-Path $payloadDirectory "partition-table.bin"),
    "0x9000", $nvsPrepared,
    "0xd000", (Join-Path $payloadDirectory "ota_data_initial.bin"),
    "0x20000", (Join-Path $payloadDirectory "xiaozhi.bin"),
    "0x600000", (Join-Path $payloadDirectory "generated_assets.bin")
)
Invoke-Esptool $flash
Remove-Item -LiteralPath $nvsPrepared -Force

Write-Host "Concluído. Backup preservado em: $backup"
Write-Host "Versão PT-BR instalada: $($release.firmware_version)"
