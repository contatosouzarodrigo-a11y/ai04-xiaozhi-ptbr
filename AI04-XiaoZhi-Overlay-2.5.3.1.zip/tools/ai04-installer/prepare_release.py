#!/usr/bin/env python3
"""Assemble a reproducible AI04 Windows migration folder from an IDF build."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PAYLOADS = {
    "bootloader.bin": Path("bootloader/bootloader.bin"),
    "partition-table.bin": Path("partition_table/partition-table.bin"),
    "ota_data_initial.bin": Path("ota_data_initial.bin"),
    "generated_assets.bin": Path("generated_assets.bin"),
    "xiaozhi.bin": Path("xiaozhi.bin"),
}
NUMERIC_VERSION = re.compile(r"^\d+(?:\.\d+)*$")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--version", required=True, help="numeric OTA version, e.g. 2.5.3.1")
    parser.add_argument(
        "--firmware-url",
        help="optional public HTTPS URL for payload/xiaozhi.bin; writes a ready OTA manifest",
    )
    parser.add_argument("--windows-tools", type=Path, help="optional directory containing esptool.exe and nvs_patch.exe")
    args = parser.parse_args()

    if not NUMERIC_VERSION.fullmatch(args.version):
        parser.error("--version must contain numeric dot-separated components")
    if args.firmware_url and not args.firmware_url.startswith("https://"):
        parser.error("--firmware-url must start with https://")
    if args.output.exists():
        parser.error(f"output directory already exists: {args.output}")

    payload_dir = args.output / "payload"
    tools_dir = args.output / "tools"
    payload_dir.mkdir(parents=True)
    tools_dir.mkdir()
    copied: dict[str, dict[str, object]] = {}
    for filename, relative_source in PAYLOADS.items():
        source = args.build_dir / relative_source
        if not source.is_file():
            parser.error(f"required build output is missing: {source}")
        destination = payload_dir / filename
        shutil.copy2(source, destination)
        copied[filename] = {"bytes": destination.stat().st_size, "sha256": sha256(destination)}

    for filename in ("install-ai04.ps1", "README.md", "nvs_patch.py"):
        shutil.copy2(ROOT / filename, args.output / filename)
    shutil.copy2(ROOT / "esptool_runner.py", tools_dir / "esptool_runner.py")
    if args.windows_tools:
        for filename in ("esptool.exe", "nvs_patch.exe"):
            source = args.windows_tools / filename
            if not source.is_file():
                parser.error(f"required Windows helper is missing: {source}")
            shutil.copy2(source, tools_dir / filename)

    manifest = {
        "format": 1,
        "board": "davinci-ai04-c3",
        "firmware_version": args.version,
        "flash_size": 8 * 1024 * 1024,
        "payload": copied,
        "flash_offsets": {
            "bootloader.bin": "0x0",
            "partition-table.bin": "0x8000",
            "ota_data_initial.bin": "0xd000",
            "xiaozhi.bin": "0x20000",
            "generated_assets.bin": "0x600000",
        },
    }
    (args.output / "release.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    ota_manifest = {
        "firmware": {
            "version": args.version,
            "url": args.firmware_url or "https://REPLACE-WITH-YOUR-HOST/ai04/xiaozhi.bin",
            "sha256": copied["xiaozhi.bin"]["sha256"],
        }
    }
    ota_manifest_name = "ota-manifest.json" if args.firmware_url else "ota-manifest.template.json"
    (args.output / ota_manifest_name).write_text(
        json.dumps(ota_manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
