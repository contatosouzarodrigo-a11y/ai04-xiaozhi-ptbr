# Instalador USB do AI04 para Windows

Este diretório gera o migrador USB que leva um AI04 da tabela de partições
legada para o layout atual de 8 MB com duas partições OTA. Ele não é um
atualizador OTA: a migração inicial precisa do cabo USB.

O instalador sempre faz uma leitura completa de 8 MiB antes de gravar. Em vez
de apagar a identidade do robô, ele preserva a NVS existente e troca somente:

- `wifi.ssid`
- `wifi.password`
- `wifi.channel`
- `wifi.ota_url`

Assim, ativação e dados não relacionados permanecem no backup/NVS. A NVS deve
ser simples (não criptografada) e válida; se não for, o processo para antes de
gravar o firmware.

## Preparar um pacote

Após uma compilação do ESP-IDF, execute. A versão precisa ser a mesma usada
para compilar o binário, pois é ela que o dispositivo compara durante o OTA:

```sh
XIAOZHI_PROJECT_VERSION=2.5.3.1 python3 scripts/build.py davinci/ai04-c3 --language pt-BR --wake-word disabled
python3 tools/ai04-installer/prepare_release.py \
  --build-dir build \
  --output releases/AI04-Updater-2.5.3.1 \
  --version 2.5.3.1
```

O pacote inclui `ota-manifest.template.json`, já com a versão e SHA-256 do
binário. Publique `payload/xiaozhi.bin` em HTTPS, troque apenas a URL no
arquivo e publique-o como o manifesto consumido pelo relay. Se a URL pública
já existir, passe `--firmware-url https://.../xiaozhi.bin` para gerar
`ota-manifest.json` pronto.

Para um pacote sem Python no PC do cliente, execute `package_windows.ps1` em
uma máquina Windows e repita o comando acima com
`--windows-tools windows-tools`.

## Usar no Windows

Conecte somente um AI04 em modo de gravação e execute PowerShell como usuário
normal:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-ai04.ps1 -Port COM5 -Ssid "MinhaRede" -OtaUrl "https://seu-relay/ota/"
```

O script pede a senha de forma oculta, cria o backup e exige a confirmação
`AI04`. Ele só aceita uma URL HTTPS do relay OTA controlado. Sem uma URL do
relay já implantado, não rode a migração: a proteção contra o firmware oficial
em inglês depende dela.

## Verificações

```sh
python3 tools/ai04-installer/test_nvs_patch.py
```

O teste cobre atualização de Wi-Fi, preservação de outro namespace, criação do
namespace Wi-Fi, rotação de página NVS e recusa de dados inválidos.
