#ifndef DAVINCI_AI04_C3_LED_STRIP_CONTROL_H_
#define DAVINCI_AI04_C3_LED_STRIP_CONTROL_H_

#include "led/circular_strip.h"

class LedStripControl {
private:
    CircularStrip* led_strip_;
    int brightness_level_;

    int LevelToBrightness(int level) const;
    StripColor RGBToColor(int red, int green, int blue) const;

public:
    explicit LedStripControl(CircularStrip* led_strip);
};

#endif  // DAVINCI_AI04_C3_LED_STRIP_CONTROL_H_
