#include "led_strip_control.h"

#include <algorithm>

#include "config.h"
#include "mcp_server.h"
#include "settings.h"

#include <esp_log.h>

#define TAG "AI04LedStrip"

int LedStripControl::LevelToBrightness(int level) const {
    return (1 << std::clamp(level, 0, 8)) - 1;
}

StripColor LedStripControl::RGBToColor(int red, int green, int blue) const {
    return {
        static_cast<uint8_t>(std::clamp(red, 0, 255)),
        static_cast<uint8_t>(std::clamp(green, 0, 255)),
        static_cast<uint8_t>(std::clamp(blue, 0, 255)),
    };
}

LedStripControl::LedStripControl(CircularStrip* led_strip)
    : led_strip_(led_strip) {
    Settings settings("led_strip");
    brightness_level_ = static_cast<int>(std::clamp<int32_t>(settings.GetInt("brightness", 4), 0, 8));
    led_strip_->SetBrightness(LevelToBrightness(brightness_level_), 4);

    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddTool("self.led_strip.get_brightness",
        "Get the brightness of the six AI04 eye LEDs (0-8).",
        PropertyList(), [this](const PropertyList&) -> ReturnValue {
            return brightness_level_;
        });

    mcp_server.AddTool("self.led_strip.set_brightness",
        "Set the brightness of the six AI04 eye LEDs (0-8).",
        PropertyList({
            Property("level", kPropertyTypeInteger, 0, 8),
        }), [this](const PropertyList& properties) -> ReturnValue {
            brightness_level_ = properties["level"].value<int>();
            ESP_LOGI(TAG, "Setting eye LED brightness to %d", brightness_level_);
            led_strip_->SetBrightness(LevelToBrightness(brightness_level_), 4);
            Settings writable_settings("led_strip", true);
            writable_settings.SetInt("brightness", brightness_level_);
            return true;
        });

    mcp_server.AddTool("self.led_strip.set_single_color",
        "Set the colour of one AI04 eye LED.",
        PropertyList({
            Property("index", kPropertyTypeInteger, 0, BUILTIN_LED_NUM - 1),
            Property("red", kPropertyTypeInteger, 0, 255),
            Property("green", kPropertyTypeInteger, 0, 255),
            Property("blue", kPropertyTypeInteger, 0, 255),
        }), [this](const PropertyList& properties) -> ReturnValue {
            led_strip_->SetSingleColor(
                properties["index"].value<int>(),
                RGBToColor(
                    properties["red"].value<int>(),
                    properties["green"].value<int>(),
                    properties["blue"].value<int>()));
            return true;
        });

    mcp_server.AddTool("self.led_strip.set_all_color",
        "Set the colour of all six AI04 eye LEDs.",
        PropertyList({
            Property("red", kPropertyTypeInteger, 0, 255),
            Property("green", kPropertyTypeInteger, 0, 255),
            Property("blue", kPropertyTypeInteger, 0, 255),
        }), [this](const PropertyList& properties) -> ReturnValue {
            led_strip_->SetAllColor(RGBToColor(
                properties["red"].value<int>(),
                properties["green"].value<int>(),
                properties["blue"].value<int>()));
            return true;
        });

    mcp_server.AddTool("self.led_strip.blink",
        "Blink the AI04 eye LEDs.",
        PropertyList({
            Property("red", kPropertyTypeInteger, 0, 255),
            Property("green", kPropertyTypeInteger, 0, 255),
            Property("blue", kPropertyTypeInteger, 0, 255),
            Property("interval", kPropertyTypeInteger, 0, 1000),
        }), [this](const PropertyList& properties) -> ReturnValue {
            led_strip_->Blink(RGBToColor(
                properties["red"].value<int>(),
                properties["green"].value<int>(),
                properties["blue"].value<int>()),
                properties["interval"].value<int>());
            return true;
        });

    mcp_server.AddTool("self.led_strip.scroll",
        "Scroll a colour across the six AI04 eye LEDs.",
        PropertyList({
            Property("red", kPropertyTypeInteger, 0, 255),
            Property("green", kPropertyTypeInteger, 0, 255),
            Property("blue", kPropertyTypeInteger, 0, 255),
            Property("length", kPropertyTypeInteger, 1, BUILTIN_LED_NUM),
            Property("interval", kPropertyTypeInteger, 0, 1000),
        }), [this](const PropertyList& properties) -> ReturnValue {
            led_strip_->Scroll(
                RGBToColor(4, 4, 4),
                RGBToColor(
                    properties["red"].value<int>(),
                    properties["green"].value<int>(),
                    properties["blue"].value<int>()),
                properties["length"].value<int>(),
                properties["interval"].value<int>());
            return true;
        });
}
