# DaVinci AI04 C3

This board definition was reconstructed from a stock `davinci-ai04-c3`
ESP32-C3 firmware image. It uses 8 MB flash, an ES8311 codec, a shared-I2C
SSD1306 128x64 display, a boot button, battery monitoring and six WS2812 eye
LEDs.

## Verified pin map

| Function | GPIO |
| --- | --- |
| ES8311 I2C SDA / SCL | 0 / 1 |
| WS2812 eye LEDs | 2 (6 LEDs) |
| Battery ADC / charge detect | ADC1_CH3 / 12 |
| I2S MCLK / WS / BCLK | 8 / 5 / 7 |
| I2S DIN / DOUT | 6 / 4 |
| ES8311 PA enable | 10 |
| Boot button | 9 |

The build has no compiled-in OTA endpoint. A production installer must set
`wifi.ota_url` to the controlled AI04 OTA relay before OTA is enabled. This
prevents an official response from silently replacing the PT-BR firmware.

The board uses the current 8 MB v2 partition map. A legacy v1 device needs one
USB migration before it can use the two-slot v2 OTA layout.

Wake-word detection is disabled in this first reconstruction. The reference
image contains no embedded WakeNet model and the ESP32-C3 has limited internal
RAM; the boot button still starts a conversation. This avoids shipping an
English wake word and preserves headroom for both OTA slots.

## Upstream tracking

For a downstream GitHub fork, `.github/workflows/ai04-upstream-candidate.yml`
checks the official source weekly, merges it into a candidate branch, builds
this board and opens a pull request only when that build succeeds. It never
publishes an OTA manifest automatically: promotion remains a deliberate review
step, so an upstream change cannot silently replace the PT-BR release.
