# AI04 C3 overlay for XiaoZhi

This overlay adds the reconstructed `davinci-ai04-c3` board, the PT-BR build
path, a controlled OTA relay, an 8 MiB USB migration package and an optional
GitHub upstream-candidate workflow to the XiaoZhi source tree.

## Apply

Start from the XiaoZhi source tree and extract this archive at its root,
allowing the four existing files below to be replaced:

- `CMakeLists.txt`
- `main/CMakeLists.txt`
- `main/Kconfig.projbuild`
- `scripts/build.py`

The archive contains all new board and tool files at their final paths. It was
verified against XiaoZhi commit `7e69845d818553ac045efbcde746b22bef6eecf6`.

## Build the first release

```sh
source "$IDF_PATH/export.sh"
XIAOZHI_PROJECT_VERSION=2.5.3.1 \
  python scripts/build.py davinci/ai04-c3 --language pt-BR --wake-word disabled
python tools/ai04-installer/prepare_release.py \
  --build-dir build \
  --output releases/AI04-Updater-2.5.3.1 \
  --version 2.5.3.1
```

The binary version and the OTA manifest version must be identical. Do not use
the legacy `99.99.99` version used by the prior installer: it blocks normal
version comparison.

## Safety model

The migration installer reads all 8 MiB before writing anything, preserves the
existing NVS data, and changes only Wi-Fi and `wifi.ota_url`. The v2 layout is
not OTA-compatible with the legacy v1 layout, so the first migration must use
USB. Do not run it until the controlled HTTPS OTA relay and release manifest
have been deployed.

Use a real 8 MiB backup from an original AI04 to validate the NVS patcher
before first-device use. The included automated tests use synthetic NVS pages
and cannot substitute for that device-specific check.

## OTA relay

Set the relay's `XIAOZHI_UPSTREAM_URL` to the current official default,
`https://api.tenclass.net/xiaozhi/ota/`, and set `AI04_MANIFEST_URL` to the
controlled HTTPS manifest that serves the release `xiaozhi.bin`. The official
cloud firmware builder cannot compile this reconstructed board until the board
definition has been merged upstream.
